package com.learning.swiggy;

public abstract class Vechile {

    private String registrationNumber;
    private String color;

    public Vechile(String registrationNumber, String color) {
        this.registrationNumber = registrationNumber;
        this.color = color;
    }
}
