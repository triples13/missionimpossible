package com.learning.swiggy;

import java.util.List;
import java.util.Map;

public class ParkingLot {

    int floorNumber;
    List<ParkingSlot> parkingSlotList;


    ParkingLot(int floorNumber,List<ParkingSlot> parkingSlotList){
        this.floorNumber = floorNumber;
        this.parkingSlotList = parkingSlotList;
    }


    public boolean checkIfParkingSlotIsAvilable(VechileType vechileType){

        boolean spaceAvilable = true;
        for(ParkingSlot parkingSlot:parkingSlotList){
             if (!parkingSlot.checkIfParkingSpaceAvailable(vechileType)){
                 spaceAvilable=false;
                 break;
        }

         return spaceAvilable;
    }


      private ParkingSlot allocateParkingSlot(Vechile vechilr)



}
