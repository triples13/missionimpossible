package com.learning.swiggy;

import java.util.List;

public class ParkingService {


    ParkingStrategy parkingStrategy;


    public void  parkVechile(Vechile vechile){

    }

    public void unParkVechile(Vechile vechile){

    }

    public List<String> getRegistrationNumberOfAllCars(String color){
        parkingStrategy.
    }
}
