package com.learning.swiggy;

public class Truck extends Vechile {


    public Truck(String registrationNumber, String color) {
        super(registrationNumber, color);
    }
}
