package com.learning.swiggy;

public class DriverClass {

    //parking slot nearest to entry
    // multi story parking lot n entry
    // ticket->registration no,color,slot


    //registartion no of all car of particular color
    // slot number of all slots particualr color car is parked



    // multiple slots per parking floor
    // bike 4 /slot  car 2/slot truck 1 slot
}
