package com.learning.swiggy;

public class Bike extends  Vechile {


    public Bike(String registrationNumber, String color) {
        super(registrationNumber, color);
    }
}
