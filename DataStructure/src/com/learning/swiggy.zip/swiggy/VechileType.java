package com.learning.swiggy;

public enum VechileType {

    Bike,
    Car,
    Truck;
}
