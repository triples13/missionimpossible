package com.learning.swiggy;

public class TestDriver {

    private static ParkingService parkingService;
    public static void main(String [] args){


       parkingService = new ParkingService();

       parkingService.getRegistrationNumberOfAllCars()

    }
}
