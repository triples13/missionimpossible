package com.learning.swiggy;

import java.util.*;

public class ParkingSlot {

    private final VechileType vechileType;
    private final Map<VechileType, PriorityQueue<ParkingSpace>> parkingMap;
    private final int avilableSpace;


    // initialize the parking slot for each vechile type
    ParkingSlot(VechileType vechileType,int avilableSpace){
        this.vechileType = vechileType;
        this.avilableSpace = avilableSpace;
        parkingMap = new HashMap<>();
        init(vechileType,avilableSpace);
    }

    public  void init(VechileType vechileType,int avilableSpace){

        PriorityQueue<ParkingSpace> priorityQueue = new PriorityQueue<>(avilableSpace, new Comparator<ParkingSpace>() {
            @Override
            public int compare(ParkingSpace o1, ParkingSpace o2) {
                return o1.slotNo-o2.slotNo;
            }
        }
        );

        switch (vechileType){

            case Bike:
                parkingMap.put(vechileType,priorityQueue);
                break;
            case Car:
                parkingMap.put(vechileType,priorityQueue);
                break;
            case Truck:
                parkingMap.put(vechileType, priorityQueue);
                break;
             default:
                 throw new IllegalArgumentException("not a vlaid type");

        }

    }

    public void  allocateParkingSpace(Vechile vechile)
    {
       ParkingSpace parkingSpace = new ParkingSpace(1,vechile);
    }

    public ParkingSpace getParkingSpace(VechileType vechileType){

        ParkingSpace parkingSpace =null;
        switch (vechileType){

            case Bike:
                if(!parkingMap.get(vechileType.Bike).isEmpty())
                    parkingSpace = parkingMap.get(vechileType).poll();
                break;
            case Car:
                if(!parkingMap.get(VechileType.Car).isEmpty())
                    parkingSpace = parkingMap.get(vechileType).poll();
                break;
            case Truck:
                if(!parkingMap.get(vechileType.Truck).isEmpty())
                    parkingSpace = parkingMap.get(vechileType).poll();
                break;
            default:
                throw new IllegalArgumentException("not a vlaid type");

        }

        return parkingSpace;

    }

    public boolean checkIfParkingSpaceAvailable( VechileType vechileType){

        boolean isAvailable = true;
        switch (vechileType){

            case Bike:
               if (parkingMap.get(vechileType.Bike).size()==0)
                   isAvailable=false;
                break;
            case Car:
                if (parkingMap.get(vechileType.Car).size()==0)
                    isAvailable=false;
                break;
            case Truck:
                if (parkingMap.get(vechileType.Truck).size()==0)
                    isAvailable=false;
                break;
            default:
                throw new IllegalArgumentException("not a vlaid type");

        }

        return isAvailable;
    }



    public VechileType getVechileType() {
        return vechileType;
    }

    public Map<VechileType, PriorityQueue<ParkingSpace>> getParkingMap() {
        return parkingMap;
    }

    public int getAvilableSpace() {
        return avilableSpace;
    }
}
