package com.learning.swiggy;

import java.util.*;

public class ParkingStrategy {

    int avilabelFloors;
    Map<VechileType,Integer> parkCapacityMap;

    ParkingStrategy(int avilableFloors, Map<VechileType,Integer> parkCapacityMap){

        this.avilabelFloors =avilableFloors;
        this.parkCapacityMap = parkCapacityMap;
        init();
    }

    public void init(){
        ParkingSlot parkingSlot1 = new ParkingSlot(VechileType.Bike,parkCapacityMap.get(VechileType.Bike));
        ParkingSlot parkingSlot2 = new ParkingSlot(VechileType.Car,parkCapacityMap.get(VechileType.Car));
        ParkingSlot parkingSlot3 = new ParkingSlot(VechileType.Truck,parkCapacityMap.get(VechileType.Car));

        List<ParkingSlot> parkingSlotList = Arrays.asList(parkingSlot1,parkingSlot2,parkingSlot3);
        ParkingLot parkingLot1 = new ParkingLot(1,parkingSlotList);
        ParkingLot parkingLot2 = new ParkingLot(2,parkingSlotList);

        List<ParkingLot> parkingLotList = Arrays.asList(parkingLot1,parkingLot2);

        priorityQueue.addAll(parkingLotList);
    }

    PriorityQueue<ParkingLot> priorityQueue = new PriorityQueue<>(avilabelFloors, new Comparator<ParkingLot>() {
        @Override
        public int compare(ParkingLot o1, ParkingLot o2) {
            return o1.floorNumber-o2.floorNumber;
        }
    });



    public boolean checkIfParkingFloorsAvailable(){
        if(priorityQueue.isEmpty())
            return false;

        return true;
    }

    private List<String> getAllAvilableCars(String color){

        for(int i=)
    }

}
