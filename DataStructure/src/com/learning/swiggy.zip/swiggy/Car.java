package com.learning.swiggy;

public class Car extends  Vechile {
    public Car(String registrationNumber, String color) {
        super(registrationNumber, color);
    }
}
