package com.learning.swiggy;

import java.util.PriorityQueue;

public class ParkingSpace {

    int slotNo;
    Vechile vechile;



    ParkingSpace(int slotNo,Vechile vechile){
       this.slotNo =slotNo;
       this.vechile = vechile;

    }

    public int getNextSequence(){

        return 0;
    }



}
